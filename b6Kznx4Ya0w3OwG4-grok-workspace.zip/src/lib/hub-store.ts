import { create } from "zustand";
import { persist } from "zustand/middleware";

export type TabId =
  | "home"
  | "combat"
  | "move"
  | "visuals"
  | "players"
  | "skins"
  | "config";

export type TargetPart = "Head" | "Torso";
export type SkinMaterial = "Neon" | "ForceField" | "Glass" | "Metal";

export interface HubState {
  menuOpen: boolean;
  tab: TabId;
  orb: { x: number; y: number };
  window: { x: number; y: number };

  aimEnabled: boolean;
  fovRadius: number;
  aimSmooth: number;
  targetPart: TargetPart;
  fovCircle: boolean;
  hitboxEnabled: boolean;
  hitboxSize: number;
  spinbot: boolean;
  spinbotSpeed: number;

  speedEnabled: boolean;
  walkSpeed: number;
  jumpEnabled: boolean;
  jumpPower: number;
  infJump: boolean;
  flyEnabled: boolean;
  flySpeed: number;
  noclip: boolean;
  bhop: boolean;
  noFall: boolean;

  espEnabled: boolean;
  espBoxes: boolean;
  espNames: boolean;
  espHealth: boolean;
  espDistance: boolean;
  espTracers: boolean;
  watermark: boolean;
  crosshair: boolean;
  fullbright: boolean;
  espColor: string;

  skinsEnabled: boolean;
  weaponColor: string;
  skinMaterial: SkinMaterial;
  appliedSkin: string | null;

  antiAfk: boolean;
  playerQuery: string;
  lastToast: string | null;

  setTab: (tab: TabId) => void;
  setMenuOpen: (open: boolean) => void;
  toggleMenu: () => void;
  setOrb: (x: number, y: number) => void;
  setWindow: (x: number, y: number) => void;
  patch: (partial: Partial<HubState>) => void;
  reset: () => void;
}

const defaults = {
  menuOpen: true,
  tab: "home" as TabId,
  orb: { x: 18, y: 18 },
  window: { x: -1, y: -1 },

  aimEnabled: false,
  fovRadius: 140,
  aimSmooth: 5,
  targetPart: "Head" as TargetPart,
  fovCircle: true,
  hitboxEnabled: false,
  hitboxSize: 5,
  spinbot: false,
  spinbotSpeed: 20,

  speedEnabled: false,
  walkSpeed: 32,
  jumpEnabled: false,
  jumpPower: 100,
  infJump: false,
  flyEnabled: false,
  flySpeed: 50,
  noclip: false,
  bhop: false,
  noFall: false,

  espEnabled: false,
  espBoxes: true,
  espNames: true,
  espHealth: true,
  espDistance: true,
  espTracers: true,
  watermark: true,
  crosshair: false,
  fullbright: false,
  espColor: "#d8dce2",

  skinsEnabled: false,
  weaponColor: "#7dffb4",
  skinMaterial: "Neon" as SkinMaterial,
  appliedSkin: null as string | null,

  antiAfk: true,
  playerQuery: "",
  lastToast: null as string | null,
};

export const useHub = create<HubState>()(
  persist(
    (set) => ({
      ...defaults,
      setTab: (tab) => set({ tab }),
      setMenuOpen: (menuOpen) => set({ menuOpen }),
      toggleMenu: () => set((s) => ({ menuOpen: !s.menuOpen })),
      setOrb: (x, y) => set({ orb: { x, y } }),
      setWindow: (x, y) => set({ window: { x, y } }),
      patch: (partial) => set(partial),
      reset: () =>
        set({
          ...defaults,
          menuOpen: true,
          lastToast: "Perfil restaurado",
        }),
    }),
    {
      name: "sovich-hub-v4",
      partialize: (s) => {
        const {
          setTab,
          setMenuOpen,
          toggleMenu,
          setOrb,
          setWindow,
          patch,
          reset,
          lastToast,
          ...rest
        } = s;
        void setTab;
        void setMenuOpen;
        void toggleMenu;
        void setOrb;
        void setWindow;
        void patch;
        void reset;
        void lastToast;
        return rest;
      },
    },
  ),
);
