import { createFileRoute } from "@tanstack/react-router";
import { HubApp } from "@/components/hub/HubApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <HubApp />;
}
