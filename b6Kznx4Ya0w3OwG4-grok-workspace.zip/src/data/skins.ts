export const KNIFE_SKINS = [
  "Butterfly · Místico",
  "Karambit · Exótico",
  "Kukri · Secreto",
  "Bayonet M9 · Recuerdo",
  "Beam Saber · Místico",
  "Prism Twins · Exótico",
];

export const SNIPER_SKINS = [
  "AWP · Místico",
  "Kar98k · Exótico",
  "M82A1 · Secreto",
  "DSR-1 · Recuerdo",
  "NTW-20 · Místico",
  "Specter · Exótico",
];

export const DEMO_PLAYERS = [
  { name: "Riven", user: "riven_x", hp: 92, dist: 18, ping: 34 },
  { name: "Kade", user: "kade99", hp: 71, dist: 29, ping: 51 },
  { name: "Nova", user: "nova.wav", hp: 100, dist: 41, ping: 22 },
  { name: "Sable", user: "sable__", hp: 44, dist: 55, ping: 67 },
  { name: "Ori", user: "ori8", hp: 83, dist: 12, ping: 19 },
  { name: "Hex", user: "hexlab", hp: 16, dist: 73, ping: 88 },
  { name: "Mira", user: "mira.twd", hp: 60, dist: 36, ping: 41 },
  { name: "Vex", user: "vexcore", hp: 100, dist: 24, ping: 27 },
];
