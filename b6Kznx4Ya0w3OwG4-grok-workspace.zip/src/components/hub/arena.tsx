import { useEffect, useRef } from "react";
import { useHub } from "@/lib/hub-store";

type Actor = {
  name: string;
  x: number;
  y: number;
  vx: number;
  hp: number;
  dist: number;
};

const NAMES = ["Riven", "Kade", "Nova", "Sable", "Ori", "Hex"];

function seedActors(): Actor[] {
  return NAMES.map((name, i) => ({
    name,
    x: 0.18 + (i % 3) * 0.28,
    y: 0.38 + Math.floor(i / 3) * 0.22,
    vx: (i % 2 === 0 ? 1 : -1) * (0.012 + i * 0.002),
    hp: 55 + i * 7,
    dist: 18 + i * 11,
  }));
}

export function Arena() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const actors = useRef(seedActors());
  const settings = useHub();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();

    const draw = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
        canvas.width = Math.floor(w * dpr);
        canvas.height = Math.floor(h * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      ctx.fillStyle = "#07080a";
      ctx.fillRect(0, 0, w, h);

      const grd = ctx.createRadialGradient(w * 0.5, h * 0.35, 20, w * 0.5, h * 0.5, Math.max(w, h) * 0.7);
      grd.addColorStop(0, "rgba(23,27,33,0.9)");
      grd.addColorStop(1, "rgba(7,8,10,0)");
      ctx.fillStyle = grd;
      ctx.fillRect(0, 0, w, h);

      ctx.strokeStyle = "rgba(232,234,237,0.04)";
      ctx.lineWidth = 1;
      const gap = 48;
      for (let x = 0; x < w; x += gap) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += gap) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      const horizon = h * 0.72;
      ctx.strokeStyle = "rgba(232,234,237,0.08)";
      ctx.beginPath();
      ctx.moveTo(0, horizon);
      ctx.lineTo(w, horizon);
      ctx.stroke();

      if (settings.fullbright) {
        ctx.fillStyle = "rgba(255,255,255,0.04)";
        ctx.fillRect(0, 0, w, h);
      }

      const color = settings.espColor || "#d8dce2";

      for (const a of actors.current) {
        a.x += a.vx * dt;
        if (a.x < 0.12 || a.x > 0.88) a.vx *= -1;
        const px = a.x * w;
        const py = a.y * h;
        const bodyH = Math.max(36, h * 0.11);
        const bodyW = bodyH / 2.1;

        ctx.fillStyle = "rgba(232,234,237,0.08)";
        ctx.beginPath();
        ctx.roundRect(px - bodyW / 2, py - bodyH / 2, bodyW, bodyH, 4);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(px, py - bodyH / 2 + 8, 5, 0, Math.PI * 2);
        ctx.fill();

        if (settings.espEnabled) {
          if (settings.espBoxes) {
            ctx.strokeStyle = color;
            ctx.lineWidth = 1.25;
            ctx.strokeRect(px - bodyW / 2 - 4, py - bodyH / 2 - 6, bodyW + 8, bodyH + 12);
          }
          if (settings.espNames) {
            ctx.fillStyle = "#ececec";
            ctx.font = "500 11px Sora, sans-serif";
            ctx.textAlign = "center";
            ctx.fillText(a.name, px, py - bodyH / 2 - 14);
          }
          if (settings.espHealth || settings.espDistance) {
            const bits = [];
            if (settings.espHealth) bits.push(`${a.hp}%`);
            if (settings.espDistance) bits.push(`${a.dist}m`);
            ctx.fillStyle = "#8a9098";
            ctx.font = "400 10px 'IBM Plex Mono', monospace";
            ctx.fillText(bits.join("  "), px, py + bodyH / 2 + 18);
          }
          if (settings.espTracers) {
            ctx.strokeStyle = color;
            ctx.globalAlpha = 0.45;
            ctx.beginPath();
            ctx.moveTo(w / 2, h);
            ctx.lineTo(px, py + bodyH / 2);
            ctx.stroke();
            ctx.globalAlpha = 1;
          }
        }
      }

      if (settings.aimEnabled && settings.fovCircle) {
        const r = settings.fovRadius;
        ctx.strokeStyle = color;
        ctx.globalAlpha = 0.55;
        ctx.beginPath();
        ctx.arc(w / 2, h * 0.46, r, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }

      if (settings.crosshair) {
        const cx = w / 2;
        const cy = h * 0.46;
        ctx.strokeStyle = "#ececec";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(cx - 8, cy);
        ctx.lineTo(cx - 2, cy);
        ctx.moveTo(cx + 2, cy);
        ctx.lineTo(cx + 8, cy);
        ctx.moveTo(cx, cy - 8);
        ctx.lineTo(cx, cy - 2);
        ctx.moveTo(cx, cy + 2);
        ctx.lineTo(cx, cy + 8);
        ctx.stroke();
      }

      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [
    settings.espEnabled,
    settings.espBoxes,
    settings.espNames,
    settings.espHealth,
    settings.espDistance,
    settings.espTracers,
    settings.espColor,
    settings.aimEnabled,
    settings.fovCircle,
    settings.fovRadius,
    settings.crosshair,
    settings.fullbright,
  ]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 h-full w-full"
      aria-hidden="true"
    />
  );
}
