import { useEffect, useRef, type PointerEvent } from "react";
import {
  Crosshair,
  Eye,
  Home,
  Minus,
  Move,
  Palette,
  Settings,
  Users,
  X,
} from "lucide-react";
import { Toaster } from "sonner";
import { Arena } from "@/components/hub/arena";
import {
  CombatPanel,
  ConfigPanel,
  HomePanel,
  MovePanel,
  PlayersPanel,
  SkinsPanel,
  VisualsPanel,
} from "@/components/hub/panels";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useHub, type TabId } from "@/lib/hub-store";

const TABS: {
  id: TabId;
  label: string;
  icon: typeof Home;
}[] = [
  { id: "home", label: "Principal", icon: Home },
  { id: "combat", label: "Combate", icon: Crosshair },
  { id: "move", label: "Movimiento", icon: Move },
  { id: "visuals", label: "Visuales", icon: Eye },
  { id: "players", label: "Jugadores", icon: Users },
  { id: "skins", label: "Skins", icon: Palette },
  { id: "config", label: "Ajustes", icon: Settings },
];

function Panel() {
  const tab = useHub((s) => s.tab);
  switch (tab) {
    case "home":
      return <HomePanel />;
    case "combat":
      return <CombatPanel />;
    case "move":
      return <MovePanel />;
    case "visuals":
      return <VisualsPanel />;
    case "players":
      return <PlayersPanel />;
    case "skins":
      return <SkinsPanel />;
    case "config":
      return <ConfigPanel />;
    default:
      return <HomePanel />;
  }
}

function useDrag(
  enabled: boolean,
  onMove: (x: number, y: number) => void,
  origin: { x: number; y: number },
) {
  const dragging = useRef(false);
  const start = useRef({ x: 0, y: 0, ox: 0, oy: 0 });
  const moved = useRef(false);

  function onPointerDown(e: PointerEvent) {
    if (!enabled) return;
    dragging.current = true;
    moved.current = false;
    start.current = {
      x: e.clientX,
      y: e.clientY,
      ox: origin.x,
      oy: origin.y,
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  }

  function onPointerMove(e: PointerEvent) {
    if (!dragging.current) return;
    const dx = e.clientX - start.current.x;
    const dy = e.clientY - start.current.y;
    if (Math.abs(dx) + Math.abs(dy) > 4) moved.current = true;
    onMove(start.current.ox + dx, start.current.oy + dy);
  }

  function onPointerUp() {
    dragging.current = false;
  }

  return { onPointerDown, onPointerMove, onPointerUp, didDrag: () => moved.current };
}

export function HubApp() {
  const menuOpen = useHub((s) => s.menuOpen);
  const tab = useHub((s) => s.tab);
  const orb = useHub((s) => s.orb);
  const win = useHub((s) => s.window);
  const watermark = useHub((s) => s.watermark);
  const setTab = useHub((s) => s.setTab);
  const toggleMenu = useHub((s) => s.toggleMenu);
  const setMenuOpen = useHub((s) => s.setMenuOpen);
  const setOrb = useHub((s) => s.setOrb);
  const setWindow = useHub((s) => s.setWindow);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Insert" || e.code === "Insert") {
        e.preventDefault();
        toggleMenu();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggleMenu]);

  const orbDrag = useDrag(true, setOrb, orb);
  const winRef = useRef<HTMLDivElement>(null);
  const draggingWin = useRef(false);
  const startWin = useRef({ x: 0, y: 0, ox: 0, oy: 0 });

  const centered = win.x < 0;

  return (
    <TooltipProvider delayDuration={200}>
      <div className="relative min-h-dvh overflow-hidden bg-bg text-fg">
        <Arena />
        <div className="pointer-events-none absolute inset-0 arena-wash" />

        {watermark ? (
          <div className="pointer-events-none absolute top-4 right-4 z-20 sm:top-6 sm:right-6">
            <p className="font-mono text-[11px] tracking-[0.22em] text-muted uppercase">
              sovich
            </p>
            <p className="mt-0.5 font-mono text-[10px] text-subtle">v4.0</p>
          </div>
        ) : null}

        <button
          type="button"
          aria-label="Abrir SOVICH"
          className="absolute z-40 flex size-11 items-center justify-center rounded-full border border-border bg-surface text-sm font-medium text-fg shadow-hub select-none"
          style={{ left: orb.x, top: orb.y }}
          onPointerDown={orbDrag.onPointerDown}
          onPointerMove={orbDrag.onPointerMove}
          onPointerUp={(e) => {
            orbDrag.onPointerUp();
            if (!orbDrag.didDrag()) toggleMenu();
            void e;
          }}
        >
          S
        </button>

        {menuOpen ? (
          <div
            ref={winRef}
            className={cn(
              "absolute z-30 flex h-[min(35rem,calc(100dvh-1.5rem))] w-[min(45rem,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-hub",
              centered
                ? "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
                : "",
            )}
            style={
              centered
                ? undefined
                : { left: win.x, top: win.y, transform: "none" }
            }
          >
            <header
              className="flex h-11 shrink-0 cursor-grab items-center gap-3 border-b border-border px-3 active:cursor-grabbing"
              onPointerDown={(e) => {
                const shell = winRef.current;
                if (!shell) return;
                const r = shell.getBoundingClientRect();
                draggingWin.current = true;
                startWin.current = {
                  x: e.clientX,
                  y: e.clientY,
                  ox: r.left,
                  oy: r.top,
                };
                setWindow(r.left, r.top);
                e.currentTarget.setPointerCapture(e.pointerId);
              }}
              onPointerMove={(e) => {
                if (!draggingWin.current) return;
                const dx = e.clientX - startWin.current.x;
                const dy = e.clientY - startWin.current.y;
                setWindow(startWin.current.ox + dx, startWin.current.oy + dy);
              }}
              onPointerUp={() => {
                draggingWin.current = false;
              }}
            >
              <span className="flex size-6 items-center justify-center rounded-sm border border-border text-[11px] font-medium">
                S
              </span>
              <span className="text-sm font-medium tracking-tight">SOVICH</span>
              <span className="font-mono text-[10px] text-subtle">v4.0</span>
              <span className="ml-auto flex items-center gap-1">
                <span className="mr-2 hidden font-mono text-[10px] text-ok sm:inline">
                  LIVE
                </span>
                <button
                  type="button"
                  aria-label="Minimizar"
                  className="flex size-8 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={() => setMenuOpen(false)}
                >
                  <Minus className="size-3.5" />
                </button>
                <button
                  type="button"
                  aria-label="Cerrar"
                  className="flex size-8 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={() => setMenuOpen(false)}
                >
                  <X className="size-3.5" />
                </button>
              </span>
            </header>

            <div className="flex min-h-0 flex-1">
              <nav className="flex w-14 shrink-0 flex-col gap-1 border-r border-border py-2">
                {TABS.map((t) => {
                  const Icon = t.icon;
                  const active = tab === t.id;
                  return (
                    <Tooltip key={t.id}>
                      <TooltipTrigger asChild>
                        <button
                          type="button"
                          aria-label={t.label}
                          aria-current={active ? "page" : undefined}
                          onClick={() => setTab(t.id)}
                          className={cn(
                            "relative mx-1.5 flex size-10 items-center justify-center rounded-md transition-colors duration-150",
                            active
                              ? "bg-elevated text-fg"
                              : "text-subtle hover:bg-elevated/70 hover:text-fg",
                          )}
                        >
                          {active ? (
                            <span className="absolute top-1/2 left-0 h-4 w-px -translate-y-1/2 bg-accent" />
                          ) : null}
                          <Icon className="size-4" strokeWidth={1.75} />
                        </button>
                      </TooltipTrigger>
                      <TooltipContent side="right">{t.label}</TooltipContent>
                    </Tooltip>
                  );
                })}
              </nav>
              <ScrollArea className="min-h-0 flex-1">
                <div className="p-4 sm:p-5">
                  <p className="mb-4 font-mono text-[11px] tracking-[0.16em] text-subtle uppercase">
                    {TABS.find((t) => t.id === tab)?.label}
                  </p>
                  <Panel />
                </div>
              </ScrollArea>
            </div>

            <footer className="flex h-9 shrink-0 items-center justify-between border-t border-border px-4">
              <span className="font-mono text-[10px] text-subtle">
                Insert · menú
              </span>
              <span className="font-mono text-[10px] text-subtle">
                TWD3  ·  universal
              </span>
            </footer>
          </div>
        ) : null}

        <Toaster
          theme="dark"
          position="bottom-right"
          toastOptions={{
            className:
              "!bg-elevated !text-fg !border-border !font-sans !text-sm",
          }}
        />
      </div>
    </TooltipProvider>
  );
}
