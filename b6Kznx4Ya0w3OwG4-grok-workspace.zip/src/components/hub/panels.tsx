import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChipGroup, Section, SliderRow, ToggleRow } from "@/components/hub/controls";
import { DEMO_PLAYERS, KNIFE_SKINS, SNIPER_SKINS } from "@/data/skins";
import {
  useHub,
  type SkinMaterial,
  type TargetPart,
} from "@/lib/hub-store";

function toastOn(label: string, on: boolean) {
  toast(on ? `${label} activado` : `${label} desactivado`);
}

export function HomePanel() {
  const s = useHub();
  const active = [
    s.aimEnabled && "Aim",
    s.espEnabled && "ESP",
    s.speedEnabled && "Speed",
    s.infJump && "Inf Jump",
    s.flyEnabled && "Fly",
    s.noclip && "Noclip",
    s.spinbot && "Spin",
    s.skinsEnabled && "Skins",
  ].filter(Boolean) as string[];

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="font-mono text-[11px] tracking-[0.18em] text-subtle uppercase">
          v4.0  ·  universal
        </p>
        <h2 className="mt-1 text-2xl font-medium tracking-tight text-fg">
          Panel de control
        </h2>
        <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted">
          Interfaz reconstruida: interruptores reales, perfiles, salto infinito
          y restauración correcta de hitbox, noclip y vuelo.
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          { k: "Módulos", v: String(active.length) },
          { k: "FOV", v: String(s.fovRadius) },
          { k: "Walk", v: String(s.walkSpeed) },
          { k: "Skin", v: s.appliedSkin ? "ON" : "—" },
        ].map((card) => (
          <div
            key={card.k}
            className="rounded-lg border border-border bg-elevated/50 px-3 py-3"
          >
            <p className="text-[11px] tracking-wide text-subtle uppercase">
              {card.k}
            </p>
            <p className="mt-1 font-mono text-lg tabular-nums text-fg">
              {card.v}
            </p>
          </div>
        ))}
      </div>
      <Section title="Atajos">
        <ToggleRow
          label="Speed"
          hint="WalkSpeed + strafe limpio"
          checked={s.speedEnabled}
          onCheckedChange={(v) => {
            s.patch({ speedEnabled: v });
            toastOn("Speed", v);
          }}
        />
        <SliderRow
          label="Velocidad"
          value={s.walkSpeed}
          min={16}
          max={150}
          onChange={(walkSpeed) => s.patch({ walkSpeed })}
        />
        <ToggleRow
          label="Super jump"
          checked={s.jumpEnabled}
          onCheckedChange={(v) => s.patch({ jumpEnabled: v })}
        />
        <ToggleRow
          label="Salto infinito"
          hint="JumpRequest — no se queda pegado al suelo"
          checked={s.infJump}
          onCheckedChange={(v) => {
            s.patch({ infJump: v });
            toastOn("Salto infinito", v);
          }}
        />
        <SliderRow
          label="Potencia de salto"
          value={s.jumpPower}
          min={50}
          max={350}
          onChange={(jumpPower) => s.patch({ jumpPower })}
        />
      </Section>
      {active.length > 0 ? (
        <p className="text-xs text-muted">
          Activos: {active.join(" · ")}
        </p>
      ) : (
        <p className="text-xs text-subtle">Ningún módulo activo.</p>
      )}
    </div>
  );
}

export function CombatPanel() {
  const s = useHub();
  return (
    <div className="flex flex-col gap-5">
      <Section title="Aim">
        <ToggleRow
          label="Aim assist"
          hint="RMB para lock · suavizado por lerp"
          checked={s.aimEnabled}
          onCheckedChange={(v) => {
            s.patch({ aimEnabled: v });
            toastOn("Aim assist", v);
          }}
        />
        <ToggleRow
          label="Círculo FOV"
          checked={s.fovCircle}
          onCheckedChange={(v) => s.patch({ fovCircle: v })}
        />
        <SliderRow
          label="Radio FOV"
          value={s.fovRadius}
          min={50}
          max={300}
          onChange={(fovRadius) => s.patch({ fovRadius })}
        />
        <SliderRow
          label="Suavizado"
          value={s.aimSmooth}
          min={1}
          max={10}
          onChange={(aimSmooth) => s.patch({ aimSmooth })}
        />
        <div className="px-3 pt-2">
          <p className="text-sm text-fg">Parte objetivo</p>
        </div>
        <ChipGroup<TargetPart>
          value={s.targetPart}
          onChange={(targetPart) => s.patch({ targetPart })}
          options={[
            { id: "Head", label: "Cabeza" },
            { id: "Torso", label: "Torso" },
          ]}
        />
      </Section>
      <Section title="Hitbox">
        <ToggleRow
          label="Extender cabeza"
          hint="Se restaura al apagar — bug v3.7 corregido"
          checked={s.hitboxEnabled}
          onCheckedChange={(v) => s.patch({ hitboxEnabled: v })}
        />
        <SliderRow
          label="Tamaño"
          value={s.hitboxSize}
          min={2}
          max={20}
          onChange={(hitboxSize) => s.patch({ hitboxSize })}
        />
      </Section>
      <Section title="Spinbot">
        <ToggleRow
          label="Spinbot"
          hint="AutoRotate se reactiva al apagar"
          checked={s.spinbot}
          onCheckedChange={(v) => s.patch({ spinbot: v })}
        />
        <SliderRow
          label="Velocidad"
          value={s.spinbotSpeed}
          min={5}
          max={100}
          onChange={(spinbotSpeed) => s.patch({ spinbotSpeed })}
        />
      </Section>
    </div>
  );
}

export function MovePanel() {
  const s = useHub();
  return (
    <div className="flex flex-col gap-5">
      <Section title="Aéreo">
        <ToggleRow
          label="Fly"
          hint="WASD + Space / Shift · PlatformStand se limpia"
          checked={s.flyEnabled}
          onCheckedChange={(v) => {
            s.patch({ flyEnabled: v });
            toastOn("Fly", v);
          }}
        />
        <SliderRow
          label="Velocidad fly"
          value={s.flySpeed}
          min={10}
          max={150}
          onChange={(flySpeed) => s.patch({ flySpeed })}
        />
        <ToggleRow
          label="Noclip"
          hint="CanCollide se restaura al desactivar"
          checked={s.noclip}
          onCheckedChange={(v) => s.patch({ noclip: v })}
        />
      </Section>
      <Section title="Suelo">
        <ToggleRow
          label="Bunny hop"
          checked={s.bhop}
          onCheckedChange={(v) => s.patch({ bhop: v })}
        />
        <ToggleRow
          label="Salto infinito"
          checked={s.infJump}
          onCheckedChange={(v) => s.patch({ infJump: v })}
        />
        <ToggleRow
          label="Sin daño de caída"
          checked={s.noFall}
          onCheckedChange={(v) => s.patch({ noFall: v })}
        />
        <ToggleRow
          label="Speed"
          checked={s.speedEnabled}
          onCheckedChange={(v) => s.patch({ speedEnabled: v })}
        />
        <SliderRow
          label="WalkSpeed"
          value={s.walkSpeed}
          min={16}
          max={150}
          onChange={(walkSpeed) => s.patch({ walkSpeed })}
        />
      </Section>
    </div>
  );
}

export function VisualsPanel() {
  const s = useHub();
  return (
    <div className="flex flex-col gap-5">
      <Section title="ESP">
        <ToggleRow
          label="ESP master"
          checked={s.espEnabled}
          onCheckedChange={(v) => {
            s.patch({ espEnabled: v });
            toastOn("ESP", v);
          }}
        />
        <ToggleRow
          label="Cajas 2D"
          checked={s.espBoxes}
          onCheckedChange={(v) => s.patch({ espBoxes: v })}
        />
        <ToggleRow
          label="Nombres"
          checked={s.espNames}
          onCheckedChange={(v) => s.patch({ espNames: v })}
        />
        <ToggleRow
          label="Vida"
          checked={s.espHealth}
          onCheckedChange={(v) => s.patch({ espHealth: v })}
        />
        <ToggleRow
          label="Distancia"
          checked={s.espDistance}
          onCheckedChange={(v) => s.patch({ espDistance: v })}
        />
        <ToggleRow
          label="Tracers"
          checked={s.espTracers}
          onCheckedChange={(v) => s.patch({ espTracers: v })}
        />
      </Section>
      <Section title="Overlay">
        <ToggleRow
          label="Watermark"
          checked={s.watermark}
          onCheckedChange={(v) => s.patch({ watermark: v })}
        />
        <ToggleRow
          label="Crosshair"
          checked={s.crosshair}
          onCheckedChange={(v) => s.patch({ crosshair: v })}
        />
        <ToggleRow
          label="Fullbright"
          checked={s.fullbright}
          onCheckedChange={(v) => s.patch({ fullbright: v })}
        />
        <div className="flex items-center justify-between gap-3 px-3 py-2.5">
          <span className="text-sm text-fg">Color ESP</span>
          <input
            type="color"
            aria-label="Color ESP"
            value={s.espColor}
            onChange={(e) => s.patch({ espColor: e.target.value })}
            className="h-8 w-12 cursor-pointer rounded-sm border border-border bg-surface"
          />
        </div>
      </Section>
    </div>
  );
}

export function PlayersPanel() {
  const s = useHub();
  const q = s.playerQuery.trim().toLowerCase();
  const list = useMemo(
    () =>
      DEMO_PLAYERS.filter(
        (p) =>
          !q ||
          p.name.toLowerCase().includes(q) ||
          p.user.toLowerCase().includes(q),
      ),
    [q],
  );

  return (
    <div className="flex flex-col gap-4">
      <Input
        value={s.playerQuery}
        onChange={(e) => s.patch({ playerQuery: e.target.value })}
        placeholder="Buscar jugador"
        aria-label="Buscar jugador"
      />
      <div className="flex flex-col gap-1.5">
        {list.length === 0 ? (
          <p className="px-1 py-6 text-center text-sm text-subtle">
            Nadie coincide con “{s.playerQuery}”.
          </p>
        ) : (
          list.map((p) => (
            <div
              key={p.user}
              className="flex items-center gap-3 rounded-lg border border-border bg-elevated/40 px-3 py-2.5"
            >
              <div className="flex size-8 shrink-0 items-center justify-center rounded-full border border-border bg-surface font-mono text-[11px] text-muted">
                {p.name.slice(0, 1)}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm text-fg">{p.name}</p>
                <p className="font-mono text-[11px] text-subtle">
                  @{p.user} · {p.dist}m · {p.hp}%
                </p>
              </div>
              <Button
                size="sm"
                variant="secondary"
                onClick={() => toast(`TP → ${p.name}`)}
              >
                TP
              </Button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export function SkinsPanel() {
  const s = useHub();
  return (
    <div className="flex flex-col gap-5">
      <div className="overflow-hidden rounded-lg border border-border bg-elevated/40 p-4">
        <p className="text-[11px] tracking-wide text-subtle uppercase">
          Vista previa
        </p>
        <div className="mt-3 flex items-end gap-4">
          <div
            className="h-16 w-40 rounded-sm"
            style={{
              background: s.skinsEnabled
                ? s.weaponColor
                : "linear-gradient(180deg, #2a2e35, #171b21)",
              boxShadow: s.skinsEnabled
                ? `0 0 24px ${s.weaponColor}55`
                : "none",
            }}
          />
          <div>
            <p className="text-sm text-fg">
              {s.appliedSkin ?? "Skin base"}
            </p>
            <p className="font-mono text-[11px] text-subtle">
              {s.skinMaterial}
            </p>
          </div>
        </div>
      </div>
      <Section title="Changer visual">
        <ToggleRow
          label="Color / material"
          checked={s.skinsEnabled}
          onCheckedChange={(v) => s.patch({ skinsEnabled: v })}
        />
        <div className="flex items-center justify-between gap-3 px-3 py-2.5">
          <span className="text-sm text-fg">Color arma</span>
          <input
            type="color"
            aria-label="Color arma"
            value={s.weaponColor}
            onChange={(e) => s.patch({ weaponColor: e.target.value })}
            className="h-8 w-12 cursor-pointer rounded-sm border border-border bg-surface"
          />
        </div>
        <ChipGroup<SkinMaterial>
          value={s.skinMaterial}
          onChange={(skinMaterial) => s.patch({ skinMaterial })}
          options={[
            { id: "Neon", label: "Neon" },
            { id: "ForceField", label: "ForceField" },
            { id: "Glass", label: "Glass" },
            { id: "Metal", label: "Metal" },
          ]}
        />
      </Section>
      <Section title="Knives">
        {KNIFE_SKINS.map((name) => (
          <button
            key={name}
            type="button"
            className="flex min-h-11 items-center justify-between px-3 text-left text-sm text-fg hover:bg-elevated/80"
            onClick={() => {
              s.patch({ appliedSkin: name });
              toast(`Skin aplicada: ${name}`);
            }}
          >
            {name}
            <span className="font-mono text-[11px] text-subtle">APPLY</span>
          </button>
        ))}
      </Section>
      <Section title="Snipers">
        {SNIPER_SKINS.map((name) => (
          <button
            key={name}
            type="button"
            className="flex min-h-11 items-center justify-between px-3 text-left text-sm text-fg hover:bg-elevated/80"
            onClick={() => {
              s.patch({ appliedSkin: name });
              toast(`Skin aplicada: ${name}`);
            }}
          >
            {name}
            <span className="font-mono text-[11px] text-subtle">APPLY</span>
          </button>
        ))}
      </Section>
      <Button
        variant="secondary"
        onClick={() => {
          s.patch({ appliedSkin: null, skinsEnabled: false });
          toast("Skins restauradas");
        }}
      >
        Restaurar skins
      </Button>
    </div>
  );
}

export function ConfigPanel() {
  const s = useHub();
  const [copied, setCopied] = useState(false);

  async function downloadLua() {
    try {
      const res = await fetch("/sovich.lua");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "sovich-hub-v4.lua";
      a.click();
      URL.revokeObjectURL(url);
      toast("Script descargado");
    } catch {
      toast("No se pudo descargar");
    }
  }

  async function copyLua() {
    try {
      const res = await fetch("/sovich.lua");
      const text = await res.text();
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast("Lua copiado al portapapeles");
      setTimeout(() => setCopied(false), 1600);
    } catch {
      toast("No se pudo copiar");
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <Section title="Perfil">
        <ToggleRow
          label="Anti-AFK"
          checked={s.antiAfk}
          onCheckedChange={(v) => s.patch({ antiAfk: v })}
        />
        <ToggleRow
          label="Watermark"
          checked={s.watermark}
          onCheckedChange={(v) => s.patch({ watermark: v })}
        />
      </Section>
      <div className="flex flex-col gap-2">
        <Button onClick={downloadLua}>Descargar script Lua v4</Button>
        <Button variant="secondary" onClick={copyLua}>
          {copied ? "Copiado" : "Copiar Lua"}
        </Button>
        <Button
          variant="secondary"
          onClick={() => {
            s.reset();
            toast("Ajustes de fábrica");
          }}
        >
          Resetear panel
        </Button>
      </div>
      <p className="text-xs leading-relaxed text-muted">
        Insert o el orbe S abre/cierra el menú. El script Lua incluye salto
        infinito, unload limpio, restauración de hitbox/noclip y esta misma
        interfaz.
      </p>
    </div>
  );
}
