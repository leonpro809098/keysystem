//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D8t7QmAV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-pwwr2vhG.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-pwwr2vhG.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Co5St_ff.js"]
	}
} });
//#endregion
export { tsrStartManifest };
