import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Palette, c as House, i as Settings, l as Eye, n as Users, o as Move, s as Minus, t as X, u as Crosshair } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { i as Viewport, n as Scrollbar, r as Thumb, t as Root } from "../_libs/radix-ui__react-scroll-area.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ChVljR_7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var defaults = {
	menuOpen: true,
	tab: "home",
	orb: {
		x: 18,
		y: 18
	},
	window: {
		x: -1,
		y: -1
	},
	aimEnabled: false,
	fovRadius: 140,
	aimSmooth: 5,
	targetPart: "Head",
	fovCircle: true,
	hitboxEnabled: false,
	hitboxSize: 5,
	spinbot: false,
	spinbotSpeed: 20,
	speedEnabled: false,
	walkSpeed: 32,
	jumpEnabled: false,
	jumpPower: 100,
	infJump: false,
	flyEnabled: false,
	flySpeed: 50,
	noclip: false,
	bhop: false,
	noFall: false,
	espEnabled: false,
	espBoxes: true,
	espNames: true,
	espHealth: true,
	espDistance: true,
	espTracers: true,
	watermark: true,
	crosshair: false,
	fullbright: false,
	espColor: "#d8dce2",
	skinsEnabled: false,
	weaponColor: "#7dffb4",
	skinMaterial: "Neon",
	appliedSkin: null,
	antiAfk: true,
	playerQuery: "",
	lastToast: null
};
var useHub = create()(persist((set) => ({
	...defaults,
	setTab: (tab) => set({ tab }),
	setMenuOpen: (menuOpen) => set({ menuOpen }),
	toggleMenu: () => set((s) => ({ menuOpen: !s.menuOpen })),
	setOrb: (x, y) => set({ orb: {
		x,
		y
	} }),
	setWindow: (x, y) => set({ window: {
		x,
		y
	} }),
	patch: (partial) => set(partial),
	reset: () => set({
		...defaults,
		menuOpen: true,
		lastToast: "Perfil restaurado"
	})
}), {
	name: "sovich-hub-v4",
	partialize: (s) => {
		const { setTab, setMenuOpen, toggleMenu, setOrb, setWindow, patch, reset, lastToast, ...rest } = s;
		return rest;
	}
}));
var NAMES = [
	"Riven",
	"Kade",
	"Nova",
	"Sable",
	"Ori",
	"Hex"
];
function seedActors() {
	return NAMES.map((name, i) => ({
		name,
		x: .18 + i % 3 * .28,
		y: .38 + Math.floor(i / 3) * .22,
		vx: (i % 2 === 0 ? 1 : -1) * (.012 + i * .002),
		hp: 55 + i * 7,
		dist: 18 + i * 11
	}));
}
function Arena() {
	const canvasRef = (0, import_react.useRef)(null);
	const actors = (0, import_react.useRef)(seedActors());
	const settings = useHub();
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		let last = performance.now();
		const draw = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			const w = canvas.clientWidth;
			const h = canvas.clientHeight;
			if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
				canvas.width = Math.floor(w * dpr);
				canvas.height = Math.floor(h * dpr);
			}
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.clearRect(0, 0, w, h);
			ctx.fillStyle = "#07080a";
			ctx.fillRect(0, 0, w, h);
			const grd = ctx.createRadialGradient(w * .5, h * .35, 20, w * .5, h * .5, Math.max(w, h) * .7);
			grd.addColorStop(0, "rgba(23,27,33,0.9)");
			grd.addColorStop(1, "rgba(7,8,10,0)");
			ctx.fillStyle = grd;
			ctx.fillRect(0, 0, w, h);
			ctx.strokeStyle = "rgba(232,234,237,0.04)";
			ctx.lineWidth = 1;
			const gap = 48;
			for (let x = 0; x < w; x += gap) {
				ctx.beginPath();
				ctx.moveTo(x, 0);
				ctx.lineTo(x, h);
				ctx.stroke();
			}
			for (let y = 0; y < h; y += gap) {
				ctx.beginPath();
				ctx.moveTo(0, y);
				ctx.lineTo(w, y);
				ctx.stroke();
			}
			const horizon = h * .72;
			ctx.strokeStyle = "rgba(232,234,237,0.08)";
			ctx.beginPath();
			ctx.moveTo(0, horizon);
			ctx.lineTo(w, horizon);
			ctx.stroke();
			if (settings.fullbright) {
				ctx.fillStyle = "rgba(255,255,255,0.04)";
				ctx.fillRect(0, 0, w, h);
			}
			const color = settings.espColor || "#d8dce2";
			for (const a of actors.current) {
				a.x += a.vx * dt;
				if (a.x < .12 || a.x > .88) a.vx *= -1;
				const px = a.x * w;
				const py = a.y * h;
				const bodyH = Math.max(36, h * .11);
				const bodyW = bodyH / 2.1;
				ctx.fillStyle = "rgba(232,234,237,0.08)";
				ctx.beginPath();
				ctx.roundRect(px - bodyW / 2, py - bodyH / 2, bodyW, bodyH, 4);
				ctx.fill();
				ctx.beginPath();
				ctx.arc(px, py - bodyH / 2 + 8, 5, 0, Math.PI * 2);
				ctx.fill();
				if (settings.espEnabled) {
					if (settings.espBoxes) {
						ctx.strokeStyle = color;
						ctx.lineWidth = 1.25;
						ctx.strokeRect(px - bodyW / 2 - 4, py - bodyH / 2 - 6, bodyW + 8, bodyH + 12);
					}
					if (settings.espNames) {
						ctx.fillStyle = "#ececec";
						ctx.font = "500 11px Sora, sans-serif";
						ctx.textAlign = "center";
						ctx.fillText(a.name, px, py - bodyH / 2 - 14);
					}
					if (settings.espHealth || settings.espDistance) {
						const bits = [];
						if (settings.espHealth) bits.push(`${a.hp}%`);
						if (settings.espDistance) bits.push(`${a.dist}m`);
						ctx.fillStyle = "#8a9098";
						ctx.font = "400 10px 'IBM Plex Mono', monospace";
						ctx.fillText(bits.join("  "), px, py + bodyH / 2 + 18);
					}
					if (settings.espTracers) {
						ctx.strokeStyle = color;
						ctx.globalAlpha = .45;
						ctx.beginPath();
						ctx.moveTo(w / 2, h);
						ctx.lineTo(px, py + bodyH / 2);
						ctx.stroke();
						ctx.globalAlpha = 1;
					}
				}
			}
			if (settings.aimEnabled && settings.fovCircle) {
				const r = settings.fovRadius;
				ctx.strokeStyle = color;
				ctx.globalAlpha = .55;
				ctx.beginPath();
				ctx.arc(w / 2, h * .46, r, 0, Math.PI * 2);
				ctx.stroke();
				ctx.globalAlpha = 1;
			}
			if (settings.crosshair) {
				const cx = w / 2;
				const cy = h * .46;
				ctx.strokeStyle = "#ececec";
				ctx.lineWidth = 1;
				ctx.beginPath();
				ctx.moveTo(cx - 8, cy);
				ctx.lineTo(cx - 2, cy);
				ctx.moveTo(cx + 2, cy);
				ctx.lineTo(cx + 8, cy);
				ctx.moveTo(cx, cy - 8);
				ctx.lineTo(cx, cy - 2);
				ctx.moveTo(cx, cy + 2);
				ctx.lineTo(cx, cy + 8);
				ctx.stroke();
			}
			raf = requestAnimationFrame(draw);
		};
		raf = requestAnimationFrame(draw);
		return () => cancelAnimationFrame(raf);
	}, [
		settings.espEnabled,
		settings.espBoxes,
		settings.espNames,
		settings.espHealth,
		settings.espDistance,
		settings.espTracers,
		settings.espColor,
		settings.aimEnabled,
		settings.fovCircle,
		settings.fovRadius,
		settings.crosshair,
		settings.fullbright
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvasRef,
		className: "absolute inset-0 h-full w-full",
		"aria-hidden": "true"
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-accent/90",
			secondary: "bg-elevated text-fg border border-border hover:bg-elevated/80",
			ghost: "text-muted hover:text-fg hover:bg-elevated",
			danger: "bg-danger/15 text-danger hover:bg-danger/25"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-8 px-3 text-xs",
			icon: "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	ref,
	className: cn("flex h-10 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg placeholder:text-subtle outline-none transition-colors duration-150 focus-visible:ring-2 focus-visible:ring-accent/40", className),
	...props
}));
Input.displayName = "Input";
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	ref,
	className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border border-border bg-elevated transition-colors duration-150 data-[state=checked]:border-accent/40 data-[state=checked]:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-3.5 translate-x-0.5 rounded-full bg-muted shadow-sm transition-transform duration-150 data-[state=checked]:translate-x-4 data-[state=checked]:bg-accent-fg" })
}));
Switch.displayName = "Switch";
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1 w-full grow overflow-hidden rounded-full bg-elevated",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-3.5 rounded-full border border-border bg-fg shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40" })]
}));
Slider.displayName = "Slider";
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "px-0.5 text-[11px] font-medium tracking-[0.16em] text-subtle uppercase",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-px overflow-hidden rounded-lg border border-border bg-elevated/40",
			children
		})]
	});
}
function ToggleRow({ label, hint, checked, onCheckedChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-h-11 cursor-pointer items-center justify-between gap-4 px-3 py-2 hover:bg-elevated/80",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex min-w-0 flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-fg",
				children: label
			}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] leading-snug text-subtle",
				children: hint
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			checked,
			onCheckedChange
		})]
	});
}
function SliderRow({ label, value, min, max, step = 1, suffix = "", onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-14 flex-col justify-center gap-2 px-3 py-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-fg",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-xs tabular-nums text-muted",
				children: [value, suffix]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
			min,
			max,
			step,
			value: [value],
			onValueChange: (v) => onChange(v[0] ?? value)
		})]
	});
}
function ChipGroup({ value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1.5 px-3 py-2.5",
		children: options.map((opt) => {
			const active = opt.id === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(opt.id),
				className: cn("h-8 rounded-md border px-3 text-xs font-medium transition-colors duration-150", active ? "border-accent/40 bg-accent text-accent-fg" : "border-border bg-surface text-muted hover:text-fg"),
				children: opt.label
			}, opt.id);
		})
	});
}
var KNIFE_SKINS = [
	"Butterfly · Místico",
	"Karambit · Exótico",
	"Kukri · Secreto",
	"Bayonet M9 · Recuerdo",
	"Beam Saber · Místico",
	"Prism Twins · Exótico"
];
var SNIPER_SKINS = [
	"AWP · Místico",
	"Kar98k · Exótico",
	"M82A1 · Secreto",
	"DSR-1 · Recuerdo",
	"NTW-20 · Místico",
	"Specter · Exótico"
];
var DEMO_PLAYERS = [
	{
		name: "Riven",
		user: "riven_x",
		hp: 92,
		dist: 18,
		ping: 34
	},
	{
		name: "Kade",
		user: "kade99",
		hp: 71,
		dist: 29,
		ping: 51
	},
	{
		name: "Nova",
		user: "nova.wav",
		hp: 100,
		dist: 41,
		ping: 22
	},
	{
		name: "Sable",
		user: "sable__",
		hp: 44,
		dist: 55,
		ping: 67
	},
	{
		name: "Ori",
		user: "ori8",
		hp: 83,
		dist: 12,
		ping: 19
	},
	{
		name: "Hex",
		user: "hexlab",
		hp: 16,
		dist: 73,
		ping: 88
	},
	{
		name: "Mira",
		user: "mira.twd",
		hp: 60,
		dist: 36,
		ping: 41
	},
	{
		name: "Vex",
		user: "vexcore",
		hp: 100,
		dist: 24,
		ping: 27
	}
];
function toastOn(label, on) {
	toast(on ? `${label} activado` : `${label} desactivado`);
}
function HomePanel() {
	const s = useHub();
	const active = [
		s.aimEnabled && "Aim",
		s.espEnabled && "ESP",
		s.speedEnabled && "Speed",
		s.infJump && "Inf Jump",
		s.flyEnabled && "Fly",
		s.noclip && "Noclip",
		s.spinbot && "Spin",
		s.skinsEnabled && "Skins"
	].filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[11px] tracking-[0.18em] text-subtle uppercase",
					children: "v4.0  ·  universal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-2xl font-medium tracking-tight text-fg",
					children: "Panel de control"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-prose text-sm leading-relaxed text-muted",
					children: "Interfaz reconstruida: interruptores reales, perfiles, salto infinito y restauración correcta de hitbox, noclip y vuelo."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					{
						k: "Módulos",
						v: String(active.length)
					},
					{
						k: "FOV",
						v: String(s.fovRadius)
					},
					{
						k: "Walk",
						v: String(s.walkSpeed)
					},
					{
						k: "Skin",
						v: s.appliedSkin ? "ON" : "—"
					}
				].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-elevated/50 px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tracking-wide text-subtle uppercase",
						children: card.k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-mono text-lg tabular-nums text-fg",
						children: card.v
					})]
				}, card.k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Atajos",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
						label: "Speed",
						hint: "WalkSpeed + strafe limpio",
						checked: s.speedEnabled,
						onCheckedChange: (v) => {
							s.patch({ speedEnabled: v });
							toastOn("Speed", v);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
						label: "Velocidad",
						value: s.walkSpeed,
						min: 16,
						max: 150,
						onChange: (walkSpeed) => s.patch({ walkSpeed })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
						label: "Super jump",
						checked: s.jumpEnabled,
						onCheckedChange: (v) => s.patch({ jumpEnabled: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
						label: "Salto infinito",
						hint: "JumpRequest — no se queda pegado al suelo",
						checked: s.infJump,
						onCheckedChange: (v) => {
							s.patch({ infJump: v });
							toastOn("Salto infinito", v);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
						label: "Potencia de salto",
						value: s.jumpPower,
						min: 50,
						max: 350,
						onChange: (jumpPower) => s.patch({ jumpPower })
					})
				]
			}),
			active.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: ["Activos: ", active.join(" · ")]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-subtle",
				children: "Ningún módulo activo."
			})
		]
	});
}
function CombatPanel() {
	const s = useHub();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Aim",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
						label: "Aim assist",
						hint: "RMB para lock · suavizado por lerp",
						checked: s.aimEnabled,
						onCheckedChange: (v) => {
							s.patch({ aimEnabled: v });
							toastOn("Aim assist", v);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
						label: "Círculo FOV",
						checked: s.fovCircle,
						onCheckedChange: (v) => s.patch({ fovCircle: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
						label: "Radio FOV",
						value: s.fovRadius,
						min: 50,
						max: 300,
						onChange: (fovRadius) => s.patch({ fovRadius })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
						label: "Suavizado",
						value: s.aimSmooth,
						min: 1,
						max: 10,
						onChange: (aimSmooth) => s.patch({ aimSmooth })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3 pt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-fg",
							children: "Parte objetivo"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipGroup, {
						value: s.targetPart,
						onChange: (targetPart) => s.patch({ targetPart }),
						options: [{
							id: "Head",
							label: "Cabeza"
						}, {
							id: "Torso",
							label: "Torso"
						}]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Hitbox",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Extender cabeza",
					hint: "Se restaura al apagar — bug v3.7 corregido",
					checked: s.hitboxEnabled,
					onCheckedChange: (v) => s.patch({ hitboxEnabled: v })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
					label: "Tamaño",
					value: s.hitboxSize,
					min: 2,
					max: 20,
					onChange: (hitboxSize) => s.patch({ hitboxSize })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Spinbot",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Spinbot",
					hint: "AutoRotate se reactiva al apagar",
					checked: s.spinbot,
					onCheckedChange: (v) => s.patch({ spinbot: v })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
					label: "Velocidad",
					value: s.spinbotSpeed,
					min: 5,
					max: 100,
					onChange: (spinbotSpeed) => s.patch({ spinbotSpeed })
				})]
			})
		]
	});
}
function MovePanel() {
	const s = useHub();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
			title: "Aéreo",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Fly",
					hint: "WASD + Space / Shift · PlatformStand se limpia",
					checked: s.flyEnabled,
					onCheckedChange: (v) => {
						s.patch({ flyEnabled: v });
						toastOn("Fly", v);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
					label: "Velocidad fly",
					value: s.flySpeed,
					min: 10,
					max: 150,
					onChange: (flySpeed) => s.patch({ flySpeed })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Noclip",
					hint: "CanCollide se restaura al desactivar",
					checked: s.noclip,
					onCheckedChange: (v) => s.patch({ noclip: v })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
			title: "Suelo",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Bunny hop",
					checked: s.bhop,
					onCheckedChange: (v) => s.patch({ bhop: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Salto infinito",
					checked: s.infJump,
					onCheckedChange: (v) => s.patch({ infJump: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Sin daño de caída",
					checked: s.noFall,
					onCheckedChange: (v) => s.patch({ noFall: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Speed",
					checked: s.speedEnabled,
					onCheckedChange: (v) => s.patch({ speedEnabled: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
					label: "WalkSpeed",
					value: s.walkSpeed,
					min: 16,
					max: 150,
					onChange: (walkSpeed) => s.patch({ walkSpeed })
				})
			]
		})]
	});
}
function VisualsPanel() {
	const s = useHub();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
			title: "ESP",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "ESP master",
					checked: s.espEnabled,
					onCheckedChange: (v) => {
						s.patch({ espEnabled: v });
						toastOn("ESP", v);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Cajas 2D",
					checked: s.espBoxes,
					onCheckedChange: (v) => s.patch({ espBoxes: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Nombres",
					checked: s.espNames,
					onCheckedChange: (v) => s.patch({ espNames: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Vida",
					checked: s.espHealth,
					onCheckedChange: (v) => s.patch({ espHealth: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Distancia",
					checked: s.espDistance,
					onCheckedChange: (v) => s.patch({ espDistance: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Tracers",
					checked: s.espTracers,
					onCheckedChange: (v) => s.patch({ espTracers: v })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
			title: "Overlay",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Watermark",
					checked: s.watermark,
					onCheckedChange: (v) => s.patch({ watermark: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Crosshair",
					checked: s.crosshair,
					onCheckedChange: (v) => s.patch({ crosshair: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Fullbright",
					checked: s.fullbright,
					onCheckedChange: (v) => s.patch({ fullbright: v })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 px-3 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-fg",
						children: "Color ESP"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "color",
						"aria-label": "Color ESP",
						value: s.espColor,
						onChange: (e) => s.patch({ espColor: e.target.value }),
						className: "h-8 w-12 cursor-pointer rounded-sm border border-border bg-surface"
					})]
				})
			]
		})]
	});
}
function PlayersPanel() {
	const s = useHub();
	const q = s.playerQuery.trim().toLowerCase();
	const list = (0, import_react.useMemo)(() => DEMO_PLAYERS.filter((p) => !q || p.name.toLowerCase().includes(q) || p.user.toLowerCase().includes(q)), [q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value: s.playerQuery,
			onChange: (e) => s.patch({ playerQuery: e.target.value }),
			placeholder: "Buscar jugador",
			"aria-label": "Buscar jugador"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-1.5",
			children: list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "px-1 py-6 text-center text-sm text-subtle",
				children: [
					"Nadie coincide con “",
					s.playerQuery,
					"”."
				]
			}) : list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 rounded-lg border border-border bg-elevated/40 px-3 py-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-8 shrink-0 items-center justify-center rounded-full border border-border bg-surface font-mono text-[11px] text-muted",
						children: p.name.slice(0, 1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm text-fg",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-[11px] text-subtle",
							children: [
								"@",
								p.user,
								" · ",
								p.dist,
								"m · ",
								p.hp,
								"%"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => toast(`TP → ${p.name}`),
						children: "TP"
					})
				]
			}, p.user))
		})]
	});
}
function SkinsPanel() {
	const s = useHub();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-lg border border-border bg-elevated/40 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] tracking-wide text-subtle uppercase",
					children: "Vista previa"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-end gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-16 w-40 rounded-sm",
						style: {
							background: s.skinsEnabled ? s.weaponColor : "linear-gradient(180deg, #2a2e35, #171b21)",
							boxShadow: s.skinsEnabled ? `0 0 24px ${s.weaponColor}55` : "none"
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						children: s.appliedSkin ?? "Skin base"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[11px] text-subtle",
						children: s.skinMaterial
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Changer visual",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
						label: "Color / material",
						checked: s.skinsEnabled,
						onCheckedChange: (v) => s.patch({ skinsEnabled: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-fg",
							children: "Color arma"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "color",
							"aria-label": "Color arma",
							value: s.weaponColor,
							onChange: (e) => s.patch({ weaponColor: e.target.value }),
							className: "h-8 w-12 cursor-pointer rounded-sm border border-border bg-surface"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipGroup, {
						value: s.skinMaterial,
						onChange: (skinMaterial) => s.patch({ skinMaterial }),
						options: [
							{
								id: "Neon",
								label: "Neon"
							},
							{
								id: "ForceField",
								label: "ForceField"
							},
							{
								id: "Glass",
								label: "Glass"
							},
							{
								id: "Metal",
								label: "Metal"
							}
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Knives",
				children: KNIFE_SKINS.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex min-h-11 items-center justify-between px-3 text-left text-sm text-fg hover:bg-elevated/80",
					onClick: () => {
						s.patch({ appliedSkin: name });
						toast(`Skin aplicada: ${name}`);
					},
					children: [name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-[11px] text-subtle",
						children: "APPLY"
					})]
				}, name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Snipers",
				children: SNIPER_SKINS.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex min-h-11 items-center justify-between px-3 text-left text-sm text-fg hover:bg-elevated/80",
					onClick: () => {
						s.patch({ appliedSkin: name });
						toast(`Skin aplicada: ${name}`);
					},
					children: [name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-[11px] text-subtle",
						children: "APPLY"
					})]
				}, name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => {
					s.patch({
						appliedSkin: null,
						skinsEnabled: false
					});
					toast("Skins restauradas");
				},
				children: "Restaurar skins"
			})
		]
	});
}
function ConfigPanel() {
	const s = useHub();
	const [copied, setCopied] = (0, import_react.useState)(false);
	async function downloadLua() {
		try {
			const blob = await (await fetch("/sovich.lua")).blob();
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = "sovich-hub-v4.lua";
			a.click();
			URL.revokeObjectURL(url);
			toast("Script descargado");
		} catch {
			toast("No se pudo descargar");
		}
	}
	async function copyLua() {
		try {
			const text = await (await fetch("/sovich.lua")).text();
			await navigator.clipboard.writeText(text);
			setCopied(true);
			toast("Lua copiado al portapapeles");
			setTimeout(() => setCopied(false), 1600);
		} catch {
			toast("No se pudo copiar");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Perfil",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Anti-AFK",
					checked: s.antiAfk,
					onCheckedChange: (v) => s.patch({ antiAfk: v })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					label: "Watermark",
					checked: s.watermark,
					onCheckedChange: (v) => s.patch({ watermark: v })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: downloadLua,
						children: "Descargar script Lua v4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: copyLua,
						children: copied ? "Copiado" : "Copiar Lua"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => {
							s.reset();
							toast("Ajustes de fábrica");
						},
						children: "Resetear panel"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-muted",
				children: "Insert o el orbe S abre/cierra el menú. El script Lua incluye salto infinito, unload limpio, restauración de hitbox/noclip y esta misma interfaz."
			})
		]
	});
}
var TooltipProvider = Provider;
var Tooltip = Root3;
var TooltipTrigger = Trigger;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 8, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 rounded-md border border-border bg-elevated px-2 py-1 text-xs text-fg shadow-hub", className),
	...props
}) }));
TooltipContent.displayName = "TooltipContent";
var ScrollArea = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root, {
	ref,
	className: cn("relative overflow-hidden", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
		className: "h-full w-full rounded-[inherit]",
		children
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scrollbar, {
		orientation: "vertical",
		className: "flex w-1.5 touch-none select-none p-px",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { className: "relative flex-1 rounded-full bg-border" })
	})]
}));
ScrollArea.displayName = "ScrollArea";
var TABS = [
	{
		id: "home",
		label: "Principal",
		icon: House
	},
	{
		id: "combat",
		label: "Combate",
		icon: Crosshair
	},
	{
		id: "move",
		label: "Movimiento",
		icon: Move
	},
	{
		id: "visuals",
		label: "Visuales",
		icon: Eye
	},
	{
		id: "players",
		label: "Jugadores",
		icon: Users
	},
	{
		id: "skins",
		label: "Skins",
		icon: Palette
	},
	{
		id: "config",
		label: "Ajustes",
		icon: Settings
	}
];
function Panel() {
	switch (useHub((s) => s.tab)) {
		case "home": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePanel, {});
		case "combat": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CombatPanel, {});
		case "move": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MovePanel, {});
		case "visuals": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VisualsPanel, {});
		case "players": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayersPanel, {});
		case "skins": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkinsPanel, {});
		case "config": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfigPanel, {});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePanel, {});
	}
}
function useDrag(enabled, onMove, origin) {
	const dragging = (0, import_react.useRef)(false);
	const start = (0, import_react.useRef)({
		x: 0,
		y: 0,
		ox: 0,
		oy: 0
	});
	const moved = (0, import_react.useRef)(false);
	function onPointerDown(e) {
		if (!enabled) return;
		dragging.current = true;
		moved.current = false;
		start.current = {
			x: e.clientX,
			y: e.clientY,
			ox: origin.x,
			oy: origin.y
		};
		e.currentTarget.setPointerCapture(e.pointerId);
	}
	function onPointerMove(e) {
		if (!dragging.current) return;
		const dx = e.clientX - start.current.x;
		const dy = e.clientY - start.current.y;
		if (Math.abs(dx) + Math.abs(dy) > 4) moved.current = true;
		onMove(start.current.ox + dx, start.current.oy + dy);
	}
	function onPointerUp() {
		dragging.current = false;
	}
	return {
		onPointerDown,
		onPointerMove,
		onPointerUp,
		didDrag: () => moved.current
	};
}
function HubApp() {
	const menuOpen = useHub((s) => s.menuOpen);
	const tab = useHub((s) => s.tab);
	const orb = useHub((s) => s.orb);
	const win = useHub((s) => s.window);
	const watermark = useHub((s) => s.watermark);
	const setTab = useHub((s) => s.setTab);
	const toggleMenu = useHub((s) => s.toggleMenu);
	const setMenuOpen = useHub((s) => s.setMenuOpen);
	const setOrb = useHub((s) => s.setOrb);
	const setWindow = useHub((s) => s.setWindow);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if (e.key === "Insert" || e.code === "Insert") {
				e.preventDefault();
				toggleMenu();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [toggleMenu]);
	const orbDrag = useDrag(true, setOrb, orb);
	const winRef = (0, import_react.useRef)(null);
	const draggingWin = (0, import_react.useRef)(false);
	const startWin = (0, import_react.useRef)({
		x: 0,
		y: 0,
		ox: 0,
		oy: 0
	});
	const centered = win.x < 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 200,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative min-h-dvh overflow-hidden bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arena, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 arena-wash" }),
				watermark ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none absolute top-4 right-4 z-20 sm:top-6 sm:right-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[11px] tracking-[0.22em] text-muted uppercase",
						children: "sovich"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 font-mono text-[10px] text-subtle",
						children: "v4.0"
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Abrir SOVICH",
					className: "absolute z-40 flex size-11 items-center justify-center rounded-full border border-border bg-surface text-sm font-medium text-fg shadow-hub select-none",
					style: {
						left: orb.x,
						top: orb.y
					},
					onPointerDown: orbDrag.onPointerDown,
					onPointerMove: orbDrag.onPointerMove,
					onPointerUp: (e) => {
						orbDrag.onPointerUp();
						if (!orbDrag.didDrag()) toggleMenu();
					},
					children: "S"
				}),
				menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: winRef,
					className: cn("absolute z-30 flex h-[min(35rem,calc(100dvh-1.5rem))] w-[min(45rem,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-hub", centered ? "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" : ""),
					style: centered ? void 0 : {
						left: win.x,
						top: win.y,
						transform: "none"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "flex h-11 shrink-0 cursor-grab items-center gap-3 border-b border-border px-3 active:cursor-grabbing",
							onPointerDown: (e) => {
								const shell = winRef.current;
								if (!shell) return;
								const r = shell.getBoundingClientRect();
								draggingWin.current = true;
								startWin.current = {
									x: e.clientX,
									y: e.clientY,
									ox: r.left,
									oy: r.top
								};
								setWindow(r.left, r.top);
								e.currentTarget.setPointerCapture(e.pointerId);
							},
							onPointerMove: (e) => {
								if (!draggingWin.current) return;
								const dx = e.clientX - startWin.current.x;
								const dy = e.clientY - startWin.current.y;
								setWindow(startWin.current.ox + dx, startWin.current.oy + dy);
							},
							onPointerUp: () => {
								draggingWin.current = false;
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-6 items-center justify-center rounded-sm border border-border text-[11px] font-medium",
									children: "S"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium tracking-tight",
									children: "SOVICH"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[10px] text-subtle",
									children: "v4.0"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-auto flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mr-2 hidden font-mono text-[10px] text-ok sm:inline",
											children: "LIVE"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "Minimizar",
											className: "flex size-8 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg",
											onPointerDown: (e) => e.stopPropagation(),
											onClick: () => setMenuOpen(false),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "Cerrar",
											className: "flex size-8 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg",
											onPointerDown: (e) => e.stopPropagation(),
											onClick: () => setMenuOpen(false),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-h-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "flex w-14 shrink-0 flex-col gap-1 border-r border-border py-2",
								children: TABS.map((t) => {
									const Icon = t.icon;
									const active = tab === t.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											"aria-label": t.label,
											"aria-current": active ? "page" : void 0,
											onClick: () => setTab(t.id),
											className: cn("relative mx-1.5 flex size-10 items-center justify-center rounded-md transition-colors duration-150", active ? "bg-elevated text-fg" : "text-subtle hover:bg-elevated/70 hover:text-fg"),
											children: [active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 left-0 h-4 w-px -translate-y-1/2 bg-accent" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
												className: "size-4",
												strokeWidth: 1.75
											})]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
										side: "right",
										children: t.label
									})] }, t.id);
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
								className: "min-h-0 flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 sm:p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-4 font-mono text-[11px] tracking-[0.16em] text-subtle uppercase",
										children: TABS.find((t) => t.id === tab)?.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {})]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
							className: "flex h-9 shrink-0 items-center justify-between border-t border-border px-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] text-subtle",
								children: "Insert · menú"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] text-subtle",
								children: "TWD3  ·  universal"
							})]
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "bottom-right",
					toastOptions: { className: "!bg-elevated !text-fg !border-border !font-sans !text-sm" }
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HubApp, {});
}
//#endregion
export { Home as component };
